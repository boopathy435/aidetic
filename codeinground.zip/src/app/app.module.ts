import { NgModule } from "@angular/core";
import { BrowserModule } from "@angular/platform-browser";
import { FormsModule } from "@angular/forms";

import { AppComponent } from "./app.component";
import { HelloComponent } from "./hello.component";
import { MatButtonModule } from "@angular/material/button";
import { ButtonComponent } from "./button/button.component";
import { GridComponent } from "./grid/grid.component";
import { TableComponent } from "./table/table.component";
import { TableService } from "./table.service";
import { HttpClientModule } from "@angular/common/http";

@NgModule({
  imports: [BrowserModule, FormsModule, MatButtonModule, HttpClientModule],
  declarations: [
    AppComponent,
    HelloComponent,
    ButtonComponent,
    GridComponent,
    TableComponent
  ],
  bootstrap: [AppComponent],
  providers: [TableService]
})
export class AppModule {}
