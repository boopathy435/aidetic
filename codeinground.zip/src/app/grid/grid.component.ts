import { Component, EventEmitter, OnInit, Output } from '@angular/core';

@Component({
  selector: 'app-grid',
  templateUrl: './grid.component.html',
  styleUrls: ['./grid.component.css']
})
export class GridComponent implements OnInit {
  @Output() open = new EventEmitter();
  constructor() { }

  ngOnInit() {
  }
  openTable(){
    this.open.emit(true);
  }
}