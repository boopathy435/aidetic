import { HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { BehaviorSubject } from "rxjs";
import { map } from "rxjs/operators";
import { Post } from "./user";

@Injectable()
export class TableService {
  displayTable = new BehaviorSubject<boolean>(false);
  displayTable$ = this.displayTable.asObservable();

  tableKey = new BehaviorSubject<string>("populate");
  tableKey$ = this.tableKey.asObservable();

  constructor(private http: HttpClient) {}

  getData() {
    return this.http.get<Post[]>("https://jsonplaceholder.typicode.com/posts");
  }
}
