import { Component, VERSION } from "@angular/core";
import { TableService } from "./table.service";

@Component({
  selector: "my-app",
  templateUrl: "./app.component.html",
  styleUrls: ["./app.component.css"]
})
export class AppComponent {
  displayTable;

  constructor(private tableService: TableService) {}

  ngOnInit() {
    this.tableService.displayTable$.subscribe(res => {
      this.displayTable = res;
    });
  }
}
