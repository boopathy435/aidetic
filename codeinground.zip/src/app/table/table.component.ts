import { Component, OnInit } from "@angular/core";
import { TableService } from "../table.service";
import { Post } from "../user";

@Component({
  selector: "app-table",
  templateUrl: "./table.component.html",
  styleUrls: ["./table.component.css"]
})
export class TableComponent implements OnInit {
  posts: Post[] = [];
  newPosts: Post[] = [];
  buttonProp = "populate";
  //populateTable = false;
  constructor(private tableService: TableService) {}

  ngOnInit() {
    this.tableService.tableKey$.subscribe(res => {
      this.buttonProp = res;
    });
  }
  propChange(prop) {
    if (prop === "populate") {
      this.tableService.getData().subscribe(res => {
        console.log(res);
        this.posts = res;
      });
      this.tableService.tableKey.next("empty");
    } else if (prop === "empty") {
      this.posts.forEach(res => {
        res.body = "-";
        res.title = "-";
        res.id = 0;
        return res;
      });
      this.tableService.tableKey.next("reset");
    } else {
      this.posts = [];
      this.tableService.tableKey.next("populate");
    }
  }

  displayTable() {
    this.tableService.displayTable.next(false);
  }
}
